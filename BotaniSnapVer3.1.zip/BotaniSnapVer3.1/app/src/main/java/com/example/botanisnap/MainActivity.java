package com.example.botanisnap;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.botanisnap.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    ActivityMainBinding binding;

    @SuppressLint("NonConstantResourceId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        replaceFragment(new Fragment());
        binding.bottomNavigationView.setBackground(null);

        // Set the bottom navigation item selected listener
        binding.bottomNavigationView.setOnItemSelectedListener(item -> {
            Fragment selectedFragment = null;

            // Change switch to if-else
            if (item.getItemId() == R.id.home) {
                selectedFragment = new Home_Fragment();
            } else if (item.getItemId() == R.id.identify) {
                selectedFragment = new Identify_Fragment();
            } else if (item.getItemId() == R.id.profile) {
                selectedFragment = new Profile_Fragment();
            }

            if (selectedFragment != null) {
                replaceFragment(selectedFragment);
            }

            return true;
        });

        // Optionally, set the default fragment to display on startup
        if (savedInstanceState == null) {
            binding.bottomNavigationView.setSelectedItemId(R.id.identify); // or any default item
        }
    }

    private void replaceFragment(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.Frame_layout, fragment);
        fragmentTransaction.commit();
    }
}
