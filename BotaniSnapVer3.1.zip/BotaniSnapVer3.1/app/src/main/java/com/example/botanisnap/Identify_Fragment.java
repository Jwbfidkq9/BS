package com.example.botanisnap;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Query;

public class Identify_Fragment extends Fragment {

    private static final int PICK_IMAGE = 1;
    private static final int CAPTURE_IMAGE = 2;
    private static final String PLANTNET_API_KEY = "2b10eEoJtMYT3YLDBIlDILPPUu";
    private TextView plantInfoTextView;
    private ImageView imageView;
    private Uri selectedImageUri;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_identify_, container, false);

        plantInfoTextView = rootView.findViewById(R.id.result);
        imageView = rootView.findViewById(R.id.imageView1);
        Button uploadButton = rootView.findViewById(R.id.upload);
        Button identifyButton = rootView.findViewById(R.id.identify);
        Button captureButton = rootView.findViewById(R.id.capture);

        uploadButton.setOnClickListener(v -> openImagePicker());
        captureButton.setOnClickListener(v -> openCamera());
        identifyButton.setOnClickListener(v -> {
            if (selectedImageUri != null) {
                identifyPlant(selectedImageUri);
            } else {
                plantInfoTextView.setText("Please upload or capture an image first.");
            }
        });

        return rootView;
    }

    private void openImagePicker() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE);
    }

    private void openCamera() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, CAPTURE_IMAGE);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == getActivity().RESULT_OK && data != null) {
            if (requestCode == PICK_IMAGE) {
                selectedImageUri = data.getData();
                imageView.setImageURI(selectedImageUri);
            } else if (requestCode == CAPTURE_IMAGE && data.getExtras() != null) {
                Bitmap bitmap = (Bitmap) data.getExtras().get("data");
                selectedImageUri = getImageUriFromBitmap(bitmap);
                imageView.setImageBitmap(bitmap);
            }
        }
    }

    private Uri getImageUriFromBitmap(Bitmap bitmap) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(getActivity().getContentResolver(), bitmap, "CapturedImage", null);
        return Uri.parse(path);
    }

    private void identifyPlant(Uri imageUri) {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://my-api.plantnet.org/v2/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        PlantNetApi service = retrofit.create(PlantNetApi.class);

        try {
            Bitmap bitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), imageUri);
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream);
            byte[] byteArray = byteArrayOutputStream.toByteArray();

            RequestBody requestFile = RequestBody.create(MediaType.parse("image/jpeg"), byteArray);
            MultipartBody.Part body = MultipartBody.Part.createFormData("images", "image.jpg", requestFile);

            Call<PlantIdentificationResponse> call = service.identifyPlant(PLANTNET_API_KEY, "en", body);
            call.enqueue(new Callback<PlantIdentificationResponse>() {
                @Override
                public void onResponse(Call<PlantIdentificationResponse> call, Response<PlantIdentificationResponse> response) {
                    if (response.isSuccessful() && response.body() != null) {
                        List<PlantIdentificationResponse.Result> results = response.body().getResults();
                        if (!results.isEmpty()) {
                            String plantName = results.get(0).getSpecies().getScientificName();
                            plantInfoTextView.setText("Plant Name: " + plantName);
                        } else {
                            plantInfoTextView.setText("No plant identified. Try again.");
                        }
                    } else {
                        plantInfoTextView.setText("Failed to identify plant. Please try again.");
                    }
                }

                @Override
                public void onFailure(Call<PlantIdentificationResponse> call, Throwable t) {
                    plantInfoTextView.setText("Error: " + t.getMessage());
                }
            });
        } catch (IOException e) {
            Log.e("ImageProcessingError", "Error processing image", e);
        }
    }

    public interface PlantNetApi {
        @Multipart
        @POST("identify/all")
        Call<PlantIdentificationResponse> identifyPlant(
                @Query("api-key") String apiKey,
                @Query("lang") String language,
                @Part MultipartBody.Part image
        );
    }

    public static class PlantIdentificationResponse {
        private List<Result> results;

        public List<Result> getResults() {
            return results;
        }

        public static class Result {
            private Species species;

            public Species getSpecies() {
                return species;
            }

            public static class Species {
                private String scientificName;

                public String getScientificName() {
                    return scientificName;
                }
            }
        }
    }
}
